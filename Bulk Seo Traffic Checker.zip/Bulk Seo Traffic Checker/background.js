chrome.runtime.onInstalled.addListener(function() {
    console.log("Bulk SEO Traffic Checker Extension Installed");
});
